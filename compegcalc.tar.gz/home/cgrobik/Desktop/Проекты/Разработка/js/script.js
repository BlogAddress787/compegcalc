let res = 0;

function Plus() {
	let inp = +document.getElementById("inp").value;
	let inp2 = +document.getElementById("inp2").value;

	res = inp + inp2;
}

function Minus() {
	let inp = +document.getElementById("inp").value;
	let inp2 = +document.getElementById("inp2").value;

	res = inp - inp2;
}

function Ymno() {
	let inp = +document.getElementById("inp").value;
	let inp2 = +document.getElementById("inp2").value;

	res = inp * inp2;
}

function Delen() {
	let inp = +document.getElementById("inp").value;
	let inp2 = +document.getElementById("inp2").value;

	res = inp / inp2;
}

function Procent() {
	let inp = +document.getElementById("inp").value;
	let inp2 = +document.getElementById("inp2").value;

	res = inp % inp2;
}

function Result() {
	let result = document.getElementById("result");
	result.innerHTML = "Результат: " + res;
}